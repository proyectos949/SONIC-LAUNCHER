package com.rl.sonic.launcher

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.GridView
import android.widget.ImageView
import android.widget.TextView
import java.text.Collator
import java.util.Locale

/** Cajón con todas las aplicaciones instaladas en la pantalla. También sirve para elegir la app de radio/música/video. */
class AppsActivity : Activity() {

    companion object {
        const val EXTRA_PICK_ROLE = "pick_role"
        const val EXTRA_COMPONENT = "component"
        const val REQ_PICK = 77
    }

    private data class AppItem(val label: String, val component: ComponentName, var icon: Drawable? = null)

    private var all: List<AppItem> = emptyList()
    private var shown: List<AppItem> = emptyList()
    private lateinit var adapter: Adapter
    private var pickRole: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_apps)
        pickRole = intent.getStringExtra(EXTRA_PICK_ROLE)
        pickRole?.let { findViewById<TextView>(R.id.appsTitle).text = "Elegir app de ${AppLauncher.label(it)}" }
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }

        adapter = Adapter()
        val grid = findViewById<GridView>(R.id.grid)
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ -> onPick(shown[pos]) }
        grid.setOnItemLongClickListener { _, _, pos, _ ->
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + shown[pos].component.packageName)))
            } catch (_: Exception) {}
            true
        }
        findViewById<EditText>(R.id.search).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { filter(s?.toString() ?: "") }
        })
        load()
    }

    @Suppress("DEPRECATION")
    override fun onResume() {
        super.onResume()
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }

    private fun load() {
        Thread {
            val pm = packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            @Suppress("DEPRECATION")
            val list: List<ResolveInfo> = pm.queryIntentActivities(i, 0)
            val col = Collator.getInstance(Locale("es", "CO"))
            val items = list.filter { it.activityInfo.packageName != packageName }
                .map { AppItem(it.loadLabel(pm).toString(), ComponentName(it.activityInfo.packageName, it.activityInfo.name)) }
                .sortedWith { a, b -> col.compare(a.label, b.label) }
            runOnUiThread { all = items; filter("") }
            // Íconos en segundo plano para no trabar pantallas lentas
            items.forEachIndexed { idx, item ->
                try { item.icon = pm.getActivityIcon(item.component) } catch (_: Exception) {}
                if (idx % 12 == 11) runOnUiThread { adapter.notifyDataSetChanged() }
            }
            runOnUiThread { adapter.notifyDataSetChanged() }
        }.start()
    }

    private fun filter(q: String) {
        val t = q.trim().lowercase(Locale.getDefault())
        shown = if (t.isEmpty()) all else all.filter { it.label.lowercase(Locale.getDefault()).contains(t) }
        adapter.notifyDataSetChanged()
    }

    private fun onPick(item: AppItem) {
        val role = pickRole
        if (role != null) {
            setResult(RESULT_OK, Intent().putExtra(EXTRA_PICK_ROLE, role).putExtra(EXTRA_COMPONENT, item.component.flattenToString()))
            finish()
        } else {
            AppLauncher.launchComponent(this, item.component.flattenToString())
        }
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val v = convertView ?: layoutInflater.inflate(R.layout.item_app, parent, false)
            val item = shown[position]
            v.findViewById<TextView>(R.id.appLabel).text = item.label
            val iv = v.findViewById<ImageView>(R.id.appIcon)
            if (item.icon != null) iv.setImageDrawable(item.icon) else iv.setImageResource(R.drawable.ic_apps)
            return v
        }
    }
}
