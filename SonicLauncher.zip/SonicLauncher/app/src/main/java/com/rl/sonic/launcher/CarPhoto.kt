package com.rl.sonic.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

/** Guarda (reducida a máx. 1600 px) la foto del carro elegida por el usuario. Conserva la transparencia de un PNG sin fondo. */
object CarPhoto {
    const val FILE = "car_photo.png"
    const val REQ = 88

    fun save(ctx: Context, uri: Uri): Boolean = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp: Bitmap? = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        if (bmp == null) false else {
            FileOutputStream(File(ctx.filesDir, FILE)).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            true
        }
    } catch (_: Exception) { false }
}
