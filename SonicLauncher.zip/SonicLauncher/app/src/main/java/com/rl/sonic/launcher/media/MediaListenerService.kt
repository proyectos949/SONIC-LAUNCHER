package com.rl.sonic.launcher.media

import android.service.notification.NotificationListenerService

/**
 * Servicio vacío: su sola existencia (activada por el usuario en
 * "Acceso a notificaciones") permite leer las sesiones multimedia activas
 * con MediaSessionManager y mostrar/controlar lo que suena en cualquier app.
 */
class MediaListenerService : NotificationListenerService()
