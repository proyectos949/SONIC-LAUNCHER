package com.rl.sonic.launcher

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.MapsInitializer
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MapStyleOptions
import com.rl.sonic.launcher.media.MediaHub
import com.rl.sonic.launcher.obd.ObdData
import com.rl.sonic.launcher.obd.ObdManager
import com.rl.sonic.launcher.ui.GaugeView
import java.util.Locale

class MainActivity : Activity(), ObdManager.Listener {

    private lateinit var prefs: Prefs
    private lateinit var obd: ObdManager
    private lateinit var media: MediaHub

    private var mapView: MapView? = null
    private var gmap: GoogleMap? = null
    private var follow = true
    private var lastLoc: Location? = null
    private var locationManager: LocationManager? = null

    private lateinit var carWeb: WebView
    private var webReady = false
    private var obdConnected = false
    private var lastObdSpeed: Int? = null

    private val dockViews = HashMap<String, View>()

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)
        obd = ObdManager(this)
        media = MediaHub(this) { showMedia(it) }

        setupStats()
        setupCar3d()
        setupMap(savedInstanceState)
        setupMedia()
        setupDock()
        setupVehiclePanel()
        requestNeededPermissions()
    }

    override fun onStart() { super.onStart(); mapView?.onStart() }

    override fun onResume() {
        super.onResume()
        hideSystemBars()
        mapView?.onResume()
        carWeb.onResume()
        applyCarView()
        media.start()
        startObd()
        startLocation()
        selectDock("home")
    }

    override fun onPause() {
        mapView?.onPause()
        carWeb.onPause()
        media.stop()
        stopLocation()
        super.onPause()
    }

    override fun onStop() { mapView?.onStop(); super.onStop() }

    override fun onDestroy() {
        obd.stop()
        mapView?.onDestroy()
        carWeb.destroy()
        super.onDestroy()
    }

    override fun onLowMemory() { super.onLowMemory(); mapView?.onLowMemory() }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        val b = Bundle()
        mapView?.onSaveInstanceState(b)
        outState.putBundle("map_state", b)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    /** Siendo launcher, "Atrás" no debe cerrar la pantalla principal. */
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val vp = findViewById<View>(R.id.vehiclePanel)
        if (vp.visibility == View.VISIBLE) showVehicle(false)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        showVehicle(false)   // botón HOME → volver al inicio
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == AppsActivity.REQ_PICK && resultCode == RESULT_OK && data != null) {
            val role = data.getStringExtra(AppsActivity.EXTRA_PICK_ROLE) ?: return
            val comp = data.getStringExtra(AppsActivity.EXTRA_COMPONENT) ?: return
            prefs.setAppFor(role, comp)
            AppLauncher.launchComponent(this, comp)
        }
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }

    // ---------------------------------------------------------------- permisos

    private fun requestNeededPermissions() {
        if (Build.VERSION.SDK_INT < 23) return
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.ACCESS_FINE_LOCATION
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.BLUETOOTH_CONNECT
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 10)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        startLocation()
        enableMyLocation()
        startObd()
    }

    private fun hasLocationPerm() = Build.VERSION.SDK_INT < 23 ||
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun hasBtPerm() = Build.VERSION.SDK_INT < 31 ||
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    // ---------------------------------------------------------------- auto 3D

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupCar3d() {
        carWeb = findViewById(R.id.carWeb)
        carWeb.setBackgroundColor(Color.TRANSPARENT)
        carWeb.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        carWeb.isVerticalScrollBarEnabled = false
        carWeb.isHorizontalScrollBarEnabled = false
        carWeb.overScrollMode = View.OVER_SCROLL_NEVER
        with(carWeb.settings) {
            javaScriptEnabled = true
            allowFileAccess = true
            cacheMode = WebSettings.LOAD_NO_CACHE
            mediaPlaybackRequiresUserGesture = true
            setSupportZoom(false)
        }
        carWeb.webChromeClient = WebChromeClient()
        carWeb.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) { webReady = true }
            @Deprecated("Deprecated in Java")
            override fun onReceivedError(view: WebView?, errorCode: Int, description: String?, failingUrl: String?) {
                showStaticCar()
            }
        }
        try {
            carWeb.loadUrl("file:///android_asset/car3d/index.html" + if (prefs.low3d) "?low=1" else "")
        } catch (e: Exception) { showStaticCar() }
    }

    /** Foto real del carro: la elegida en Ajustes, o la incluida en el APK (assets/car_photo.png). */
    private fun loadCarPhoto(): android.graphics.Bitmap? {
        if (!prefs.useCarPhoto) return null
        return try {
            val f = java.io.File(filesDir, CarPhoto.FILE)
            if (f.exists()) android.graphics.BitmapFactory.decodeFile(f.absolutePath)
            else assets.open("car_photo.png").use { android.graphics.BitmapFactory.decodeStream(it) }
        } catch (_: Exception) { null }
    }

    private fun applyCarView() {
        val iv = findViewById<ImageView>(R.id.carStatic)
        val photo = loadCarPhoto()
        if (photo != null) {
            iv.setImageBitmap(photo)
            iv.visibility = View.VISIBLE
            carWeb.visibility = View.GONE
            carWeb.onPause()
        } else {
            iv.setImageResource(R.drawable.car_sonic)
            iv.visibility = View.GONE
            carWeb.visibility = View.VISIBLE
        }
    }

    private fun showStaticCar() {
        carWeb.visibility = View.GONE
        findViewById<View>(R.id.carStatic).visibility = View.VISIBLE
    }

    private fun js(code: String) { if (webReady) carWeb.evaluateJavascript(code, null) }

    // ---------------------------------------------------------------- tarjetas OBD

    private class Stat(root: View) {
        val icon: ImageView = root.findViewById(R.id.statIcon)
        val value: TextView = root.findViewById(R.id.statValue)
        val label: TextView = root.findViewById(R.id.statLabel)
        val bar: ProgressBar = root.findViewById(R.id.statBar)
    }

    private lateinit var sTemp: Stat
    private lateinit var sFuel: Stat
    private lateinit var sBatt: Stat
    private lateinit var sOil: Stat

    private fun setupStats() {
        sTemp = Stat(findViewById(R.id.statTemp)).apply { icon.setImageResource(R.drawable.ic_temp); label.setText(R.string.temp) }
        sFuel = Stat(findViewById(R.id.statFuel)).apply { icon.setImageResource(R.drawable.ic_fuel); label.setText(R.string.fuel) }
        sBatt = Stat(findViewById(R.id.statBatt)).apply { icon.setImageResource(R.drawable.ic_battery); label.setText(R.string.battery) }
        sOil = Stat(findViewById(R.id.statOil)).apply { icon.setImageResource(R.drawable.ic_oil); label.text = "Aceite °C" }
        findViewById<View>(R.id.obdPill).setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
    }

    private fun setStat(s: Stat, text: String, pct: Int?, state: Int) {
        s.value.text = text
        s.bar.progress = (pct ?: 0).coerceIn(0, 100)
        val col = when (state) { 2 -> c(R.color.danger); 1 -> c(R.color.warn); else -> c(R.color.cyan) }
        s.bar.progressTintList = android.content.res.ColorStateList.valueOf(col)
        s.icon.imageTintList = android.content.res.ColorStateList.valueOf(if (state > 0) col else c(R.color.text_dim))
    }

    private fun startObd() {
        if (prefs.demo) { obd.startDemo(); return }
        val mac = prefs.obdMac
        if (mac.isNullOrEmpty()) { onObdState(ObdManager.State.DISCONNECTED, "Configurar OBD"); obd.stop(); return }
        if (!hasBtPerm()) { onObdState(ObdManager.State.DISCONNECTED, "Permiso Bluetooth"); return }
        obd.startBluetooth(mac)
    }

    override fun onObdState(state: ObdManager.State, message: String) {
        val dot = findViewById<View>(R.id.obdDot)
        findViewById<TextView>(R.id.obdText).text = message
        dot.setBackgroundResource(when (state) {
            ObdManager.State.CONNECTED, ObdManager.State.DEMO -> R.drawable.dot_on
            ObdManager.State.CONNECTING -> R.drawable.dot_wait
            else -> R.drawable.dot_off
        })
        obdConnected = state == ObdManager.State.CONNECTED || state == ObdManager.State.DEMO
        if (!obdConnected) { lastObdSpeed = null; js("setEngine(false)") }
    }

    override fun onObdData(data: ObdData) {
        // Temperatura del motor: normal 85–105 °C en el motor 1.6/1.8 Ecotec
        val t = data.coolantC
        setStat(sTemp, t?.let { "$it°" } ?: "—", t?.let { ((it - 40) * 100 / 90) },
            when { t == null -> 0; t >= 112 -> 2; t >= 104 -> 1; else -> 0 })
        val f = data.fuelPct
        setStat(sFuel, f?.let { "${it.toInt()}%" } ?: "—", f?.toInt(),
            when { f == null -> 0; f <= 8 -> 2; f <= 15 -> 1; else -> 0 })
        val v = data.voltage
        setStat(sBatt, v?.let { String.format(Locale.US, "%.1fV", it) } ?: "—", v?.let { ((it - 11f) / 4f * 100).toInt() },
            when { v == null -> 0; v < 11.8f || v > 15.2f -> 2; v < 12.3f -> 1; else -> 0 })
        val o = data.oilTempC
        setStat(sOil, o?.let { "$it°" } ?: "N/D", o?.let { ((it - 40) * 100 / 100) },
            when { o == null -> 0; o >= 130 -> 2; o >= 120 -> 1; else -> 0 })

        val mil = findViewById<TextView>(R.id.milBadge)
        if (data.milOn == true || (data.dtcCount ?: 0) > 0) {
            mil.visibility = View.VISIBLE
            mil.text = "Check Engine · ${data.dtcCount ?: 0}"
        } else mil.visibility = View.GONE

        // Panel completo
        gRpm.setValue(data.rpm?.toFloat()); gSpeed.setValue(data.speedKmh?.toFloat())
        gTemp.setValue(data.coolantC?.toFloat()); gFuel.setValue(data.fuelPct)
        gBatt.setValue(data.voltage); gOil.setValue(data.oilTempC?.toFloat())
        gLoad.setValue(data.loadPct); gIntake.setValue(data.intakeC?.toFloat())
        findViewById<TextView>(R.id.dtcText).text =
            if (data.dtcs.isEmpty()) "Sin códigos de falla" + (if (data.oilTempC == null) "  ·  Temperatura de aceite no reportada por la ECU" else "")
            else "Códigos de falla: " + data.dtcs.joinToString("  ")

        js("setEngine(${(data.rpm ?: 0) > 300})")
        data.speedKmh?.let { lastObdSpeed = it; setSpeed(it); js("setSpeed($it)") }
    }

    // ---------------------------------------------------------------- panel vehículo

    private lateinit var gRpm: GaugeView; private lateinit var gSpeed: GaugeView
    private lateinit var gTemp: GaugeView; private lateinit var gFuel: GaugeView
    private lateinit var gBatt: GaugeView; private lateinit var gOil: GaugeView
    private lateinit var gLoad: GaugeView; private lateinit var gIntake: GaugeView

    private fun setupVehiclePanel() {
        gRpm = findViewById<GaugeView>(R.id.gRpm).setup("RPM", "rpm", 0f, 7000f, warnHigh = 5500f, dangerHigh = 6300f)
        gSpeed = findViewById<GaugeView>(R.id.gSpeed).setup("Velocidad", "km/h", 0f, 200f, warnHigh = 120f)
        gTemp = findViewById<GaugeView>(R.id.gTemp).setup("Motor", "°C", 40f, 130f, warnHigh = 104f, dangerHigh = 112f)
        gFuel = findViewById<GaugeView>(R.id.gFuel).setup("Combustible", "%", 0f, 100f, warnLow = 15f)
        gBatt = findViewById<GaugeView>(R.id.gBatt).setup("Batería", "V", 10f, 16f, warnLow = 12.2f, warnHigh = 15.0f, decimals = 1)
        gOil = findViewById<GaugeView>(R.id.gOil).setup("Aceite", "°C", 40f, 150f, warnHigh = 120f, dangerHigh = 130f)
        gLoad = findViewById<GaugeView>(R.id.gLoad).setup("Carga", "%", 0f, 100f, warnHigh = 85f)
        gIntake = findViewById<GaugeView>(R.id.gIntake).setup("Admisión", "°C", -10f, 80f, warnHigh = 60f)
        findViewById<View>(R.id.btnCloseVehicle).setOnClickListener { showVehicle(false) }
        findViewById<View>(R.id.carCard).setOnClickListener { showVehicle(true) }
        findViewById<View>(R.id.milBadge).setOnClickListener { showVehicle(true) }
        findViewById<View>(R.id.btnClearDtc).setOnClickListener {
            android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Borrar códigos de falla")
                .setMessage("Hazlo con el motor apagado y la llave en ON. Si la falla persiste, el testigo volverá a encenderse.")
                .setPositiveButton("Borrar") { _, _ -> obd.clearDtcs(); Toast.makeText(this, "Solicitud enviada", Toast.LENGTH_SHORT).show() }
                .setNegativeButton("Cancelar", null).show()
        }
    }

    private fun showVehicle(show: Boolean) {
        val p = findViewById<View>(R.id.vehiclePanel)
        if (show == (p.visibility == View.VISIBLE)) return
        if (show) {
            p.alpha = 0f; p.translationY = 30f; p.visibility = View.VISIBLE
            p.animate().alpha(1f).translationY(0f).setDuration(220).start()
            selectDock("car")
        } else {
            p.animate().alpha(0f).translationY(30f).setDuration(180).withEndAction { p.visibility = View.GONE }.start()
            selectDock("home")
        }
    }

    // ---------------------------------------------------------------- mapa

    private fun setupMap(state: Bundle?) {
        val mv = findViewById<MapView>(R.id.map)
        val placeholder = findViewById<TextView>(R.id.mapPlaceholder)
        val gmsOk = try {
            com.google.android.gms.common.GoogleApiAvailability.getInstance()
                .isGooglePlayServicesAvailable(this) == com.google.android.gms.common.ConnectionResult.SUCCESS
        } catch (e: Throwable) { false }

        if (!BuildConfig.HAS_MAPS_KEY || !gmsOk) {
            mv.visibility = View.GONE
            placeholder.visibility = View.VISIBLE
            if (!gmsOk) placeholder.text = "Servicios de Google no disponibles.\nToca para abrir tu app de mapas."
            placeholder.setOnClickListener { AppLauncher.open(this, "nav", prefs) }
        } else {
            mapView = mv
            try { MapsInitializer.initialize(applicationContext) } catch (_: Exception) {}
            mv.onCreate(state?.getBundle("map_state"))
            mv.getMapAsync { map ->
                gmap = map
                try { map.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.map_style_dark)) } catch (_: Exception) {}
                map.uiSettings.isMyLocationButtonEnabled = false
                map.uiSettings.isMapToolbarEnabled = false
                map.uiSettings.isCompassEnabled = false
                map.uiSettings.isTiltGesturesEnabled = true
                map.isTrafficEnabled = true
                map.isBuildingsEnabled = true
                enableMyLocation()
                map.setOnCameraMoveStartedListener { reason ->
                    if (reason == GoogleMap.OnCameraMoveStartedListener.REASON_GESTURE) follow = false
                }
                map.setOnMapLongClickListener { ll ->
                    AppLauncher.navigateTo(this, "${ll.latitude},${ll.longitude}", prefs)
                }
                // Posición inicial: Medellín, hasta que llegue el GPS
                val start = lastLoc?.let { LatLng(it.latitude, it.longitude) } ?: LatLng(6.2442, -75.5812)
                map.moveCamera(CameraUpdateFactory.newLatLngZoom(start, 15f))
            }
        }
        findViewById<View>(R.id.btnRecenter).setOnClickListener { follow = true; lastLoc?.let { moveCamera(it, true) } }
        findViewById<View>(R.id.btnWhere).setOnClickListener { AppLauncher.openMapsSearch(this, prefs) }
        findViewById<View>(R.id.btnHome).setOnClickListener { goSaved(prefs.homeAddr, "Casa") }
        findViewById<View>(R.id.btnWork).setOnClickListener { goSaved(prefs.workAddr, "Trabajo") }
    }

    private fun goSaved(addr: String, name: String) {
        if (addr.isBlank()) {
            Toast.makeText(this, "Configura la dirección de $name en Ajustes", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, SettingsActivity::class.java))
        } else AppLauncher.navigateTo(this, addr, prefs)
    }

    @SuppressLint("MissingPermission")
    private fun enableMyLocation() {
        val m = gmap ?: return
        if (hasLocationPerm()) try { m.isMyLocationEnabled = true } catch (_: SecurityException) {}
    }

    private fun moveCamera(loc: Location, animate: Boolean) {
        val m = gmap ?: return
        val moving = loc.hasSpeed() && loc.speed > 2f
        val cam = CameraPosition.Builder()
            .target(LatLng(loc.latitude, loc.longitude))
            .zoom(if (moving) 17f else 16f)
            .tilt(if (moving) 50f else 0f)
            .bearing(if (moving && loc.hasBearing()) loc.bearing else m.cameraPosition.bearing)
            .build()
        if (animate) m.animateCamera(CameraUpdateFactory.newCameraPosition(cam), 800, null)
        else m.moveCamera(CameraUpdateFactory.newCameraPosition(cam))
    }

    private val locListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            lastLoc = location
            if (follow) moveCamera(location, true)
            if (lastObdSpeed == null && location.hasSpeed()) {
                val kmh = (location.speed * 3.6f).toInt()
                setSpeed(kmh); js("setSpeed($kmh)")
            }
        }
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    @SuppressLint("MissingPermission")
    private fun startLocation() {
        if (!hasLocationPerm()) return
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        locationManager = lm
        try {
            for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                if (lm.isProviderEnabled(p)) {
                    lm.requestLocationUpdates(p, 1000L, 1f, locListener)
                    lm.getLastKnownLocation(p)?.let { if (lastLoc == null) lastLoc = it }
                }
            }
            lastLoc?.let { moveCamera(it, false) }
        } catch (_: Exception) {}
    }

    private fun stopLocation() { try { locationManager?.removeUpdates(locListener) } catch (_: Exception) {} }

    private fun setSpeed(kmh: Int) { findViewById<TextView>(R.id.speedValue).text = kmh.toString() }

    // ---------------------------------------------------------------- multimedia

    private fun setupMedia() {
        findViewById<ImageButton>(R.id.btnPlay).setOnClickListener { media.playPause() }
        findViewById<ImageButton>(R.id.btnNext).setOnClickListener { media.next() }
        findViewById<ImageButton>(R.id.btnPrev).setOnClickListener { media.prev() }
        findViewById<View>(R.id.mediaCard).setOnClickListener {
            if (!media.hasPermission()) {
                Toast.makeText(this, "Activa \"Sonic Launcher\" en Acceso a notificaciones", Toast.LENGTH_LONG).show()
                try { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) } catch (_: Exception) {}
            } else {
                val pkg = media.currentPackage()
                if (pkg == null || !AppLauncher.launchPackage(this, pkg)) AppLauncher.open(this, "music", prefs)
            }
        }
    }

    private fun showMedia(i: MediaHub.Info) {
        val title = findViewById<TextView>(R.id.mediaTitle)
        val artist = findViewById<TextView>(R.id.mediaArtist)
        val art = findViewById<ImageView>(R.id.mediaArt)
        val play = findViewById<ImageButton>(R.id.btnPlay)
        if (!i.permitted) {
            title.setText(R.string.no_media)
            artist.setText(R.string.tap_to_enable_media)
        } else {
            title.text = i.title ?: getString(R.string.no_media)
            artist.text = i.artist ?: (i.appPackage?.let { appLabel(it) } ?: "")
        }
        title.isSelected = true   // activa el marquee
        if (i.art != null) {
            art.setPadding(0, 0, 0, 0); art.imageTintList = null; art.setImageBitmap(i.art)
            art.clipToOutline = true
        } else {
            val p = (14 * resources.displayMetrics.density).toInt()
            art.setPadding(p, p, p, p); art.setImageResource(R.drawable.ic_music)
            art.imageTintList = android.content.res.ColorStateList.valueOf(c(R.color.text_dim))
        }
        play.setImageResource(if (i.playing) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) { "" }

    // ---------------------------------------------------------------- dock

    private fun setupDock() {
        val dock = findViewById<LinearLayout>(R.id.dock)
        addDock(dock, "home", R.drawable.ic_home, getString(R.string.home)) { showVehicle(false) }
        addDock(dock, "car", R.drawable.ic_rpm, "Vehículo") { showVehicle(true) }
        addDock(dock, "nav", R.drawable.ic_nav, getString(R.string.nav)) { AppLauncher.open(this, "nav", prefs) }
        addDock(dock, "radio", R.drawable.ic_radio, getString(R.string.radio)) { AppLauncher.open(this, "radio", prefs) }
        addDock(dock, "music", R.drawable.ic_music, getString(R.string.music)) { AppLauncher.open(this, "music", prefs) }
        addDock(dock, "video", R.drawable.ic_video, getString(R.string.video)) { AppLauncher.open(this, "video", prefs) }
        addDock(dock, "apps", R.drawable.ic_apps, getString(R.string.apps)) { startActivity(Intent(this, AppsActivity::class.java)) }
        addDock(dock, "settings", R.drawable.ic_settings, getString(R.string.settings)) { startActivity(Intent(this, SettingsActivity::class.java)) }
    }

    private fun addDock(parent: LinearLayout, key: String, icon: Int, label: String, action: () -> Unit) {
        val d = resources.displayMetrics.density
        val item = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundResource(R.drawable.bg_dock_item)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                marginStart = (2 * d).toInt(); marginEnd = (2 * d).toInt()
            }
            isClickable = true
            setOnClickListener { action() }
        }
        val iv = ImageView(this).apply {
            setImageResource(icon)
            layoutParams = LinearLayout.LayoutParams((24 * d).toInt(), (24 * d).toInt())
            tag = "icon"
        }
        val tv = TextView(this).apply {
            text = label; textSize = 11f; setTextColor(c(R.color.text_dim))
            gravity = Gravity.CENTER; maxLines = 1
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = (3 * d).toInt() }
            tag = "label"
        }
        item.addView(iv); item.addView(tv)
        parent.addView(item)
        dockViews[key] = item
    }

    private fun selectDock(key: String) {
        for ((k, v) in dockViews) {
            val sel = k == key
            v.isSelected = sel
            val col = c(if (sel) R.color.accent else R.color.text_dim)
            (v.findViewWithTag<View>("icon") as? ImageView)?.imageTintList = android.content.res.ColorStateList.valueOf(if (sel) col else c(R.color.text))
            (v.findViewWithTag<View>("label") as? TextView)?.setTextColor(col)
        }
    }

    @Suppress("DEPRECATION")
    private fun c(id: Int): Int = resources.getColor(id)
}
