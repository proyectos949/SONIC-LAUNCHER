package com.rl.sonic.launcher

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var box: LinearLayout
    private val d by lazy { resources.displayMetrics.density }
    private val appRows = HashMap<String, TextView>()
    private var obdRow: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        prefs = Prefs(this)
        box = findViewById(R.id.container)
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        build()
    }

    @Suppress("DEPRECATION")
    override fun onResume() {
        super.onResume()
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }

    private fun build() {
        header("Vehículo · OBD-II")
        obdRow = row("Adaptador OBD (ELM327 Bluetooth)", prefs.obdName ?: "Sin elegir — empareja el adaptador primero en Bluetooth (PIN 1234 o 0000)") { pickObd() }
        toggle("Modo demostración", "Muestra datos simulados sin adaptador OBD", prefs.demo) { prefs.demo = it }
        row("Foto de mi carro", "Elige una foto de tu Sonic (de lado o en 3/4; mejor PNG sin fondo)") {
            val i = Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE)
            try { startActivityForResult(Intent.createChooser(i, "Foto del carro"), CarPhoto.REQ) } catch (_: Exception) { toast("No hay galería disponible") }
        }
        toggle("Mostrar foto real del carro", "Desactívalo para ver el modelo 3D", prefs.useCarPhoto) { prefs.useCarPhoto = it }
        toggle("Modelo 3D en modo ahorro", "Para pantallas con procesador lento (reinicia el launcher)", prefs.low3d) { prefs.low3d = it }

        header("Aplicaciones de la pantalla")
        for (role in listOf("nav", "radio", "music", "video")) {
            appRows[role] = row("App de ${AppLauncher.label(role)}", appName(role)) {
                startActivityForResult(Intent(this, AppsActivity::class.java).putExtra(AppsActivity.EXTRA_PICK_ROLE, role), AppsActivity.REQ_PICK)
            }
        }

        header("Destinos rápidos")
        field("Dirección de Casa", prefs.homeAddr) { prefs.homeAddr = it }
        field("Dirección del Trabajo", prefs.workAddr) { prefs.workAddr = it }

        header("Permisos y sistema")
        row("Permitir ver la música en reproducción", "Activa \"Sonic Launcher\" en Acceso a notificaciones") {
            try { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) } catch (_: Exception) { toast("No disponible en esta pantalla") }
        }
        row("Usar como pantalla de inicio", "Elige Sonic Launcher y marca \"Siempre\"") {
            try { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) } catch (_: Exception) {
                startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        row("Bluetooth del sistema", "Emparejar el adaptador OBD") {
            try { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) } catch (_: Exception) {}
        }
        row("Ajustes de Android", "Configuración completa de la pantalla") {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) {}
        }
        row("Acerca de", "Sonic Launcher ${BuildConfig.VERSION_NAME} · Chevrolet Sonic 2014 Sedán") {}
    }

    // ------------------------------------------------------------- OBD

    @SuppressLint("MissingPermission")
    private fun pickObd() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 5); return
        }
        @Suppress("DEPRECATION")
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) { toast("Esta pantalla no tiene Bluetooth"); return }
        if (!adapter.isEnabled) { toast("Enciende el Bluetooth"); return }
        val devices = adapter.bondedDevices?.toList().orEmpty()
        if (devices.isEmpty()) {
            toast("Empareja primero el adaptador OBD en Bluetooth")
            try { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) } catch (_: Exception) {}
            return
        }
        // Los ELM327 suelen llamarse "OBDII", "OBD2", "V-LINK", "ELM327"…
        val sorted = devices.sortedByDescending { (it.name ?: "").uppercase().let { n -> n.contains("OBD") || n.contains("ELM") || n.contains("LINK") } }
        val names = sorted.map { "${it.name ?: "Sin nombre"}\n${it.address}" }.toTypedArray()
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Elige el adaptador OBD")
            .setItems(names) { _, which ->
                val dev = sorted[which]
                prefs.obdMac = dev.address
                prefs.obdName = dev.name ?: dev.address
                prefs.demo = false
                obdRow?.text = prefs.obdName
                toast("Adaptador guardado. Modo demostración desactivado.")
                recreate()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 5 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) pickObd()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CarPhoto.REQ && resultCode == RESULT_OK && data?.data != null) {
            if (CarPhoto.save(this, data.data!!)) { prefs.useCarPhoto = true; toast("Foto guardada"); recreate() }
            else toast("No se pudo leer la imagen")
            return
        }
        if (requestCode == AppsActivity.REQ_PICK && resultCode == RESULT_OK && data != null) {
            val role = data.getStringExtra(AppsActivity.EXTRA_PICK_ROLE) ?: return
            prefs.setAppFor(role, data.getStringExtra(AppsActivity.EXTRA_COMPONENT))
            appRows[role]?.text = appName(role)
        }
    }

    private fun appName(role: String): String {
        val comp = prefs.appFor(role) ?: return "Automático"
        val pkg = ComponentName.unflattenFromString(comp)?.packageName ?: comp
        return try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg }
    }

    // ------------------------------------------------------------- UI helpers

    private fun px(v: Int) = (v * d).toInt()
    @Suppress("DEPRECATION")
    private fun col(id: Int) = resources.getColor(id)

    private fun header(t: String) {
        box.addView(TextView(this).apply {
            text = t.uppercase(); textSize = 12f; letterSpacing = 0.1f; setTextColor(col(R.color.accent))
            setPadding(px(6), px(18), px(6), px(8))
        })
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setBackgroundResource(R.drawable.bg_card)
        setPadding(px(18), px(14), px(18), px(14))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = px(8) }
    }

    private fun texts(parent: LinearLayout, title: String, sub: String): TextView {
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        column.addView(TextView(this).apply { text = title; textSize = 16f; setTextColor(col(R.color.text)) })
        val s = TextView(this).apply { text = sub; textSize = 13f; setTextColor(col(R.color.text_dim)) }
        column.addView(s)
        parent.addView(column)
        return s
    }

    private fun row(title: String, sub: String, onClick: () -> Unit): TextView {
        val c = card()
        val s = texts(c, title, sub)
        c.isClickable = true
        c.setOnClickListener { onClick() }
        box.addView(c)
        return s
    }

    @Suppress("DEPRECATION")
    private fun toggle(title: String, sub: String, value: Boolean, onChange: (Boolean) -> Unit) {
        val c = card()
        texts(c, title, sub)
        val sw = Switch(this).apply { isChecked = value; setOnCheckedChangeListener { _, b -> onChange(b) } }
        c.addView(sw)
        c.setOnClickListener { sw.toggle() }
        box.addView(c)
    }

    private fun field(title: String, value: String, onSave: (String) -> Unit) {
        val c = card()
        c.orientation = LinearLayout.VERTICAL
        c.addView(TextView(this).apply { text = title; textSize = 16f; setTextColor(col(R.color.text)) })
        val et = EditText(this).apply {
            setText(value); hint = "Ej: Carrera 43A # 1-50, Medellín"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_POSTAL_ADDRESS
            setTextColor(col(R.color.text)); setHintTextColor(col(R.color.text_faint)); textSize = 15f
            setBackgroundResource(R.drawable.bg_search); setPadding(px(12), px(10), px(12), px(10))
            imeOptions = android.view.inputmethod.EditorInfo.IME_FLAG_NO_EXTRACT_UI
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = px(8) }
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(q: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(q: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(e: android.text.Editable?) { onSave(e?.toString()?.trim() ?: "") }
            })
        }
        c.addView(et)
        box.addView(c)
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}
