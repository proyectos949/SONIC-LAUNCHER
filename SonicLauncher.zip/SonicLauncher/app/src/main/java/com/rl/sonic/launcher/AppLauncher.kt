package com.rl.sonic.launcher

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast

/** Abre las apps de radio, música, video y navegación que ya trae la pantalla Android. */
object AppLauncher {

    // Paquetes habituales en radios Android chinas (FYT/SYU, MTCD/Microntek, TopWay, TS, Allwinner, etc.)
    private val RADIO = listOf(
        "com.syu.radio", "com.microntek.radio", "com.ts.radio", "com.tw.radio", "com.hct.radio",
        "com.android.fmradio", "com.caf.fmradio", "com.qti.fmradio", "com.android.car.radio",
        "com.autochips.radio", "com.nwd.radio", "com.ex.radio", "com.car.radio", "com.zt.radio",
        "com.mediatek.FMRadio", "com.android.radio", "com.ts.MainUI"
    )
    private val MUSIC = listOf(
        "com.syu.music", "com.microntek.music", "com.ts.music", "com.tw.music", "com.android.music",
        "com.spotify.music", "com.google.android.apps.youtube.music", "deezer.android.app"
    )
    private val VIDEO = listOf(
        "com.syu.video", "com.microntek.media", "com.ts.video", "com.tw.video", "com.android.video",
        "org.videolan.vlc", "com.mxtech.videoplayer.ad", "com.google.android.youtube",
        "com.android.gallery3d", "com.google.android.apps.photos"
    )
    private val NAV = listOf("com.google.android.apps.maps", "com.waze", "com.google.android.apps.mapslite")

    fun open(act: Activity, role: String, prefs: Prefs) {
        // 1) La app que el usuario eligió en Ajustes
        prefs.appFor(role)?.let { if (launchComponent(act, it)) return }
        // 2) Categorías estándar de Android
        val category = when (role) {
            "music" -> Intent.CATEGORY_APP_MUSIC
            "video" -> Intent.CATEGORY_APP_GALLERY
            "nav" -> Intent.CATEGORY_APP_MAPS
            else -> null
        }
        // 3) Paquetes conocidos
        val list = when (role) { "radio" -> RADIO; "music" -> MUSIC; "video" -> VIDEO; else -> NAV }
        for (pkg in list) if (launchPackage(act, pkg)) return
        if (category != null) {
            try {
                act.startActivity(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, category).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (_: Exception) {}
        }
        // 4) No se encontró: pedir al usuario que la elija
        Toast.makeText(act, "Elige la app de ${label(role)}", Toast.LENGTH_SHORT).show()
        act.startActivityForResult(
            Intent(act, AppsActivity::class.java).putExtra(AppsActivity.EXTRA_PICK_ROLE, role),
            AppsActivity.REQ_PICK
        )
    }

    fun label(role: String) = when (role) { "radio" -> "radio"; "music" -> "música"; "video" -> "video"; else -> "navegación" }

    fun launchPackage(ctx: Context, pkg: String): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        return try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true } catch (_: Exception) { false }
    }

    /** component = "paquete/clase" */
    fun launchComponent(ctx: Context, component: String): Boolean {
        val cn = ComponentName.unflattenFromString(component) ?: return launchPackage(ctx, component)
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(cn)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return try { ctx.startActivity(i); true } catch (_: Exception) { launchPackage(ctx, cn.packageName) }
    }

    fun isInstalled(ctx: Context, pkg: String): Boolean = try {
        @Suppress("DEPRECATION") ctx.packageManager.getPackageInfo(pkg, 0); true
    } catch (_: PackageManager.NameNotFoundException) { false }

    /** Inicia navegación giro a giro en Google Maps (o Waze / cualquier app de mapas). */
    fun navigateTo(act: Activity, query: String, prefs: Prefs) {
        val q = Uri.encode(query)
        val chosen = prefs.appFor("nav")?.let { ComponentName.unflattenFromString(it)?.packageName ?: it }
        val tries = mutableListOf<Intent>()
        if (chosen == "com.waze" || (chosen == null && !isInstalled(act, "com.google.android.apps.maps") && isInstalled(act, "com.waze")))
            tries += Intent(Intent.ACTION_VIEW, Uri.parse("https://waze.com/ul?q=$q&navigate=yes")).setPackage("com.waze")
        tries += Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=$q")).setPackage("com.google.android.apps.maps")
        tries += Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$q"))
        for (i in tries) {
            try { act.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (_: ActivityNotFoundException) {}
        }
        Toast.makeText(act, "No hay app de mapas instalada", Toast.LENGTH_LONG).show()
    }

    /** Abre la búsqueda de Google Maps ("¿A dónde vamos?"). */
    fun openMapsSearch(act: Activity, prefs: Prefs) {
        prefs.appFor("nav")?.let { if (launchComponent(act, it)) return }
        try {
            act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")).setPackage("com.google.android.apps.maps")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return
        } catch (_: Exception) {}
        for (p in NAV) if (launchPackage(act, p)) return
        Toast.makeText(act, "Instala Google Maps desde Play Store", Toast.LENGTH_LONG).show()
    }
}
