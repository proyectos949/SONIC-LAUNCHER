package com.rl.sonic.launcher.obd

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.Locale
import java.util.UUID
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Datos del vehículo. null = no disponible / no soportado por la ECU. */
data class ObdData(
    var coolantC: Int? = null,      // 01 05  Temperatura refrigerante (°C)
    var fuelPct: Float? = null,     // 01 2F  Nivel de combustible (%)
    var rpm: Int? = null,           // 01 0C
    var speedKmh: Int? = null,      // 01 0D
    var voltage: Float? = null,     // AT RV  Voltaje batería (pin 16 del OBD)
    var oilTempC: Int? = null,      // 01 5C  Temperatura aceite (no todas las ECU)
    var loadPct: Float? = null,     // 01 04  Carga del motor (%)
    var intakeC: Int? = null,       // 01 0F  Temperatura aire de admisión
    var throttlePct: Float? = null, // 01 11
    var milOn: Boolean? = null,     // 01 01  Testigo "Check Engine"
    var dtcCount: Int? = null,
    var dtcs: List<String> = emptyList()  // 03
)

/**
 * Cliente OBD-II para adaptadores ELM327 Bluetooth clásico (SPP).
 * El Chevrolet Sonic 2014 usa protocolo CAN ISO 15765-4 (11 bit, 500 kbps); se usa ATSP0 (auto).
 */
class ObdManager(private val listener: Listener) {

    interface Listener {
        fun onObdState(state: State, message: String)
        fun onObdData(data: ObdData)
    }

    enum class State { DISCONNECTED, CONNECTING, CONNECTED, DEMO }

    companion object {
        private const val TAG = "ObdManager"
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private const val RETRY_MS = 8000L
    }

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    @Volatile private var socket: BluetoothSocket? = null
    private var worker: Thread? = null
    private val data = ObdData()
    private val unsupported = HashMap<String, Int>()

    fun startBluetooth(mac: String) {
        stop()
        running = true
        worker = Thread({ btLoop(mac) }, "obd-bt").apply { isDaemon = true; start() }
    }

    fun startDemo() {
        stop()
        running = true
        worker = Thread({ demoLoop() }, "obd-demo").apply { isDaemon = true; start() }
    }

    fun stop() {
        running = false
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        worker?.interrupt()
        worker = null
    }

    /** Borra los códigos de falla (modo 04). Sólo con motor apagado y llave en ON. */
    fun clearDtcs() {
        val s = socket ?: return
        val lock = this
        Thread {
            try {
                synchronized(lock) { cmd(s.outputStream, s.inputStream, "04", 5000) }
            } catch (e: Exception) { Log.w(TAG, "clear dtc", e) }
        }.start()
    }

    private fun postState(st: State, msg: String) = main.post { listener.onObdState(st, msg) }
    private fun postData() { val copy = data.copy(); main.post { listener.onObdData(copy) } }

    // ------------------------------------------------------------------ Bluetooth

    @SuppressLint("MissingPermission")
    private fun btLoop(mac: String) {
        @Suppress("DEPRECATION")
        val adapter = BluetoothAdapter.getDefaultAdapter()
        while (running) {
            try {
                if (adapter == null || !adapter.isEnabled) {
                    postState(State.DISCONNECTED, "Bluetooth apagado")
                    sleep(RETRY_MS); continue
                }
                postState(State.CONNECTING, "Conectando OBD…")
                val dev = adapter.getRemoteDevice(mac)
                adapter.cancelDiscovery()
                val s = try {
                    dev.createRfcommSocketToServiceRecord(SPP_UUID).also { it.connect() }
                } catch (first: IOException) {
                    // Muchos ELM327 chinos sólo aceptan el canal 1 por reflexión
                    val m = dev.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                    (m.invoke(dev, 1) as BluetoothSocket).also { it.connect() }
                }
                socket = s
                val out = s.outputStream
                val inp = s.inputStream
                initElm(out, inp)
                postState(State.CONNECTED, "OBD conectado · ${dev.name ?: mac}")
                unsupported.clear()
                pollLoop(out, inp)
            } catch (e: Exception) {
                Log.w(TAG, "OBD error: ${e.message}")
                postState(State.DISCONNECTED, "OBD desconectado")
                try { socket?.close() } catch (_: Exception) {}
                socket = null
                sleep(RETRY_MS)
            }
        }
        postState(State.DISCONNECTED, "OBD desconectado")
    }

    private fun initElm(out: OutputStream, inp: InputStream) {
        cmd(out, inp, "ATZ", 3000)      // reset
        sleep(800)
        for (c in listOf("ATE0", "ATL0", "ATS0", "ATH0", "ATAT1", "ATSP0")) cmd(out, inp, c, 1500)
        cmd(out, inp, "0100", 8000)     // fuerza la detección de protocolo ("SEARCHING...")
    }

    private fun pollLoop(out: OutputStream, inp: InputStream) {
        var cycle = 0
        while (running) {
            synchronized(this) {
                // Rápidos: cada ciclo
                pid(out, inp, "010C") { b -> data.rpm = ((b[0] * 256) + b[1]) / 4 }
                pid(out, inp, "010D") { b -> data.speedKmh = b[0] }
                if (cycle % 2 == 0) {
                    pid(out, inp, "0104") { b -> data.loadPct = b[0] * 100f / 255f }
                    pid(out, inp, "0111") { b -> data.throttlePct = b[0] * 100f / 255f }
                }
                // Lentos: cada 5 ciclos
                if (cycle % 5 == 0) {
                    pid(out, inp, "0105") { b -> data.coolantC = b[0] - 40 }
                    pid(out, inp, "012F") { b -> data.fuelPct = b[0] * 100f / 255f }
                    pid(out, inp, "015C") { b -> data.oilTempC = b[0] - 40 }
                    pid(out, inp, "010F") { b -> data.intakeC = b[0] - 40 }
                    val rv = cmd(out, inp, "ATRV", 1500)
                    Regex("(\\d{1,2}\\.\\d)").find(rv)?.let { data.voltage = it.value.toFloat() }
                    if (data.voltage == null) pid(out, inp, "0142") { b -> data.voltage = ((b[0] * 256) + b[1]) / 1000f }
                }
                // Fallas: cada 30 ciclos
                if (cycle % 30 == 0) {
                    pid(out, inp, "0101") { b ->
                        data.milOn = (b[0] and 0x80) != 0
                        data.dtcCount = b[0] and 0x7F
                    }
                    if ((data.dtcCount ?: 0) > 0) data.dtcs = readDtcs(out, inp) else data.dtcs = emptyList()
                }
            }
            postData()
            cycle++
            sleep(250)
        }
    }

    /** Ejecuta un PID de modo 01 y entrega los bytes de datos (después de 41 xx). */
    private fun pid(out: OutputStream, inp: InputStream, code: String, parse: (IntArray) -> Unit) {
        if ((unsupported[code] ?: 0) >= 3) return
        val resp = cmd(out, inp, code, 2500)
        val hex = resp.uppercase(Locale.US).replace(Regex("[^0-9A-F\\n]"), "")
        val key = "4" + code.substring(1)            // "010C" -> "410C"
        val line = hex.lines().firstOrNull { it.contains(key) }
        if (line == null) {
            unsupported[code] = (unsupported[code] ?: 0) + 1
            return
        }
        unsupported[code] = 0
        val payload = line.substring(line.indexOf(key) + key.length)
        val bytes = payload.chunked(2).filter { it.length == 2 }.map { it.toInt(16) }.toIntArray()
        if (bytes.isEmpty()) return
        try { parse(bytes) } catch (_: Exception) {}
    }

    private fun readDtcs(out: OutputStream, inp: InputStream): List<String> {
        val resp = cmd(out, inp, "03", 5000).uppercase(Locale.US)
        val result = ArrayList<String>()
        for (raw in resp.lines()) {
            var h = raw.replace(Regex("[^0-9A-F]"), "")
            val i = h.indexOf("43"); if (i < 0) continue
            h = h.substring(i + 2)
            // En CAN el primer byte es la cantidad de códigos
            if ((h.length / 2) % 2 == 1) h = h.substring(2)
            h.chunked(4).filter { it.length == 4 && it != "0000" }.forEach { result.add(decodeDtc(it)) }
        }
        return result.distinct()
    }

    private fun decodeDtc(h: String): String {
        val first = h[0].digitToInt(16)
        val letter = "PCBU"[first shr 2]
        return "$letter${first and 0x3}${h.substring(1)}"
    }

    /** Envía un comando y lee hasta el prompt '>' con timeout. */
    private fun cmd(out: OutputStream, inp: InputStream, c: String, timeoutMs: Long): String {
        out.write((c + "\r").toByteArray()); out.flush()
        val sb = StringBuilder()
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            if (inp.available() > 0) {
                val ch = inp.read()
                if (ch < 0) throw IOException("stream closed")
                if (ch.toChar() == '>') break
                sb.append(ch.toChar())
            } else {
                try { Thread.sleep(8) } catch (e: InterruptedException) { throw IOException("interrupted") }
            }
        }
        return sb.toString().replace("\r", "\n").replace("SEARCHING...", "").trim()
    }

    private fun sleep(ms: Long) { try { Thread.sleep(ms) } catch (_: InterruptedException) {} }

    // ------------------------------------------------------------------ Demo

    private fun demoLoop() {
        postState(State.DEMO, "Modo demostración")
        var t = 0.0
        data.coolantC = 40; data.fuelPct = 68f; data.voltage = 14.1f
        while (running) {
            t += 0.25
            val spd = max(0.0, 45 + 35 * sin(t / 9.0) + 8 * sin(t / 2.3))
            data.speedKmh = spd.toInt()
            data.rpm = (800 + spd * 32 + 300 * sin(t / 1.7)).toInt().coerceAtLeast(750)
            data.loadPct = (25 + 30 * sin(t / 3.0)).toFloat().coerceIn(5f, 95f)
            data.throttlePct = (data.loadPct!! * 0.7f)
            data.coolantC = min(92, (data.coolantC ?: 40) + if (t % 2.0 < 0.3) 1 else 0)
            data.oilTempC = ((data.coolantC ?: 40) + 6)
            data.intakeC = 31
            data.fuelPct = max(4f, (data.fuelPct ?: 68f) - 0.01f)
            data.voltage = (13.9 + 0.2 * sin(t / 5.0)).toFloat()
            data.milOn = false; data.dtcCount = 0; data.dtcs = emptyList()
            postData()
            sleep(250)
        }
    }
}
