package com.rl.sonic.launcher

import android.content.Context
import android.content.SharedPreferences

class Prefs(ctx: Context) {
    private val p: SharedPreferences = ctx.getSharedPreferences("sonic_launcher", Context.MODE_PRIVATE)

    var obdMac: String?
        get() = p.getString("obd_mac", null)
        set(v) = p.edit().putString("obd_mac", v).apply()
    var obdName: String?
        get() = p.getString("obd_name", null)
        set(v) = p.edit().putString("obd_name", v).apply()
    var demo: Boolean
        get() = p.getBoolean("demo", true)
        set(v) = p.edit().putBoolean("demo", v).apply()
    var low3d: Boolean
        get() = p.getBoolean("low3d", false)
        set(v) = p.edit().putBoolean("low3d", v).apply()
    /** true = mostrar la foto real del carro en lugar del modelo 3D */
    var useCarPhoto: Boolean
        get() = p.getBoolean("use_car_photo", true)
        set(v) = p.edit().putBoolean("use_car_photo", v).apply()
    var homeAddr: String
        get() = p.getString("home_addr", "") ?: ""
        set(v) = p.edit().putString("home_addr", v).apply()
    var workAddr: String
        get() = p.getString("work_addr", "") ?: ""
        set(v) = p.edit().putString("work_addr", v).apply()

    /** role = radio | music | video | nav */
    fun appFor(role: String): String? = p.getString("pkg_$role", null)
    fun setAppFor(role: String, component: String?) = p.edit().putString("pkg_$role", component).apply()
}
