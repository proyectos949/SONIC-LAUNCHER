package com.rl.sonic.launcher.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.min

/** Indicador circular minimalista (arco de 270°) con color según rango. */
class GaugeView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    var label = ""
    var unit = ""
    var minV = 0f
    var maxV = 100f
    var warnLow: Float? = null      // por debajo → advertencia (p.ej. combustible)
    var warnHigh: Float? = null     // por encima → advertencia (p.ej. temperatura)
    var dangerHigh: Float? = null
    var decimals = 0

    private var value: Float? = null
    private var shown = 0f
    private var anim: ValueAnimator? = null

    private val dp = resources.displayMetrics.density
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Color.parseColor("#222A33") }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif-light", Typeface.NORMAL) }
    private val sub = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#8A96A3"); textAlign = Paint.Align.CENTER; letterSpacing = 0.08f }
    private val rect = RectF()

    fun setup(label: String, unit: String, min: Float, max: Float, warnLow: Float? = null, warnHigh: Float? = null, dangerHigh: Float? = null, decimals: Int = 0): GaugeView {
        this.label = label; this.unit = unit; minV = min; maxV = max
        this.warnLow = warnLow; this.warnHigh = warnHigh; this.dangerHigh = dangerHigh; this.decimals = decimals
        invalidate(); return this
    }

    fun setValue(v: Float?) {
        value = v
        val target = v ?: minV
        anim?.cancel()
        anim = ValueAnimator.ofFloat(shown, target).apply {
            duration = 450; interpolator = DecelerateInterpolator()
            addUpdateListener { shown = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun colorFor(v: Float?): Int {
        if (v == null) return Color.parseColor("#4E5966")
        dangerHigh?.let { if (v >= it) return Color.parseColor("#FF4D4F") }
        warnHigh?.let { if (v >= it) return Color.parseColor("#FFB020") }
        warnLow?.let { if (v <= it) return Color.parseColor("#FFB020") }
        return Color.parseColor("#3DD9EB")
    }

    override fun onDraw(c: Canvas) {
        val size = min(width, height).toFloat()
        val stroke = size * 0.075f
        val cx = width / 2f; val cy = height / 2f + size * 0.04f
        val r = size / 2f - stroke * 1.2f
        rect.set(cx - r, cy - r, cx + r, cy + r)
        track.strokeWidth = stroke
        c.drawArc(rect, 135f, 270f, false, track)

        val frac = ((shown - minV) / (maxV - minV)).coerceIn(0f, 1f)
        val col = colorFor(value)
        if (value != null && frac > 0f) {
            glow.strokeWidth = stroke * 2.2f
            glow.color = (col and 0x00FFFFFF) or 0x22000000
            c.drawArc(rect, 135f, 270f * frac, false, glow)
            arc.strokeWidth = stroke
            arc.color = col
            c.drawArc(rect, 135f, 270f * frac, false, arc)
        }
        txt.textSize = size * 0.22f
        val vText = value?.let { if (decimals == 0) it.toInt().toString() else String.format("%.${decimals}f", it) } ?: "—"
        c.drawText(vText, cx, cy + txt.textSize * 0.30f, txt)
        sub.textSize = size * 0.085f
        c.drawText(unit, cx, cy + txt.textSize * 0.30f + sub.textSize * 1.5f, sub)
        sub.textSize = size * 0.09f
        c.drawText(label.uppercase(), cx, cy + r + stroke * 0.4f, sub)
        if (stroke < 1f * dp) return
    }
}
