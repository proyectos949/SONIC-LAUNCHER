package com.rl.sonic.launcher.media

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import android.provider.Settings
import android.view.KeyEvent

/** Lee y controla la sesión multimedia activa (Spotify, YouTube Music, radio, reproductor del equipo…). */
class MediaHub(private val ctx: Context, private val onChange: (Info) -> Unit) {

    data class Info(
        val title: String?, val artist: String?, val art: Bitmap?,
        val playing: Boolean, val appPackage: String?, val permitted: Boolean
    )

    private val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val component = ComponentName(ctx, MediaListenerService::class.java)
    private var controller: MediaController? = null

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = publish()
        override fun onPlaybackStateChanged(state: PlaybackState?) = publish()
        override fun onSessionDestroyed() { bind(null) }
    }

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        bind(pickController(list))
    }

    fun hasPermission(): Boolean {
        val flat = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: return false
        return flat.contains(ctx.packageName)
    }

    fun start() {
        if (!hasPermission()) { onChange(Info(null, null, null, audio.isMusicActive, null, false)); return }
        try {
            msm.addOnActiveSessionsChangedListener(sessionsListener, component)
            bind(pickController(msm.getActiveSessions(component)))
        } catch (e: SecurityException) {
            onChange(Info(null, null, null, audio.isMusicActive, null, false))
        }
    }

    fun stop() {
        try { msm.removeOnActiveSessionsChangedListener(sessionsListener) } catch (_: Exception) {}
        controller?.unregisterCallback(cb)
        controller = null
    }

    private fun pickController(list: List<MediaController>?): MediaController? {
        if (list.isNullOrEmpty()) return null
        return list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list[0]
    }

    private fun bind(c: MediaController?) {
        controller?.unregisterCallback(cb)
        controller = c
        c?.registerCallback(cb)
        publish()
    }

    private fun publish() {
        val c = controller
        val md = c?.metadata
        val art = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
        val playing = c?.playbackState?.state == PlaybackState.STATE_PLAYING
        onChange(Info(title, artist, art, playing, c?.packageName, true))
    }

    fun playPause() {
        val c = controller
        if (c != null) {
            if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause() else c.transportControls.play()
        } else key(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
    }

    fun next() { controller?.transportControls?.skipToNext() ?: key(KeyEvent.KEYCODE_MEDIA_NEXT) }
    fun prev() { controller?.transportControls?.skipToPrevious() ?: key(KeyEvent.KEYCODE_MEDIA_PREVIOUS) }
    fun currentPackage(): String? = controller?.packageName

    /** Funciona aun sin permiso: envía la tecla multimedia al reproductor activo. */
    private fun key(code: Int) {
        val t = SystemClock.uptimeMillis()
        audio.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
        audio.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
    }
}
